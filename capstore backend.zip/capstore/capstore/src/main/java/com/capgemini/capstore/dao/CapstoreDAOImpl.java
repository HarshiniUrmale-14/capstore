package com.capgemini.capstore.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.PersistenceUnit;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.capgemini.capstore.beans.FeedbackBean;
import com.capgemini.capstore.beans.LoginBean;
import com.capgemini.capstore.beans.OrderBean;
import com.capgemini.capstore.beans.OrderStatusBean;
import com.capgemini.capstore.beans.PermanentMerchantBean;
import com.capgemini.capstore.beans.ProductBean;
import com.capgemini.capstore.beans.TemporaryCustomerBean;
import com.capgemini.capstore.beans.TemporaryMerchantBean;
import com.capgemini.capstore.customexception.CapstoreException;

@Repository
public class CapstoreDAOImpl implements CapstoreDAO {

	@PersistenceUnit
	private EntityManagerFactory entityManagerFactory;
	EntityManager entityManager;
	EntityTransaction entityTransaction;
	

	@Override
	public boolean addThirdMerchant(PermanentMerchantBean permanentMerchantBean) {
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		boolean isAdded = false;
		try {
			entityTransaction.begin();
			entityManager.persist(permanentMerchantBean);
			entityTransaction.commit();
			isAdded = true;

		} catch (Exception e) {
			throw new CapstoreException("Merchant Already Exists..");
		}
		entityManager.close();

		return isAdded;
	}

	@Override
	public boolean register(PermanentMerchantBean permanentMerchantBean) {
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		boolean isAdded = false;
		try {
			entityTransaction.begin();
			entityManager.persist(permanentMerchantBean);
			entityTransaction.commit();
			isAdded = true;

		} catch (Exception e) {
			throw new CapstoreException("Merchant Already Exists..");
		}
		entityManager.close();

		return isAdded;
	}

	@Override
	public boolean deleteMerchant(String Email) {
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		boolean isDeleted = false;

		try {
			entityTransaction.begin();
			PermanentMerchantBean permanentMerchantBean = entityManager.find(PermanentMerchantBean.class, Email);
			entityManager.remove(permanentMerchantBean);
			entityTransaction.commit();
			

		} catch (Exception e) {
			throw new CapstoreException("Merchant cannot be deleted..");
		}
		
		try {
			entityTransaction.begin();
		      Query query = entityManager.createQuery("DELETE FROM LoginBean e WHERE e.email = :email ");
		      query.setParameter("email", Email);
		      int rowsDeleted = query.executeUpdate();
		      entityTransaction.commit();
		     
			isDeleted = true;
		}
		catch (Exception e) {
			throw new CapstoreException("Merchant cannot be deleted..");
		}
		entityManager.close();
		return isDeleted;
	}

	@Override
	public List<FeedbackBean> viewFeedback() {
		List<FeedbackBean> feedbackList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from FeedbackBean";
		Query query = entityManager.createQuery(jpql);
		try {
			feedbackList = query.getResultList();
		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Feedback list not found..");
		}
		entityManager.close();
		return feedbackList;

	}

	@Override
	public List<OrderBean> viewPlaceOrder() {
		List<OrderBean> orderList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from OrderBean";

		try {
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
			orderList = query.getResultList();
			entityTransaction.commit();
		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... placed order not found..");
		}
		entityManager.close();
		return orderList;
	}

	@Override
	public List<OrderStatusBean> viewCancelledOrder() {
		List<OrderStatusBean> cancelList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from OrderStatusBean";
		Query query = entityManager.createQuery(jpql);
		try {
			cancelList = query.getResultList();

		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Cancelled list not found..");
		}
		entityManager.close();
		return cancelList;
	}

	@Override
	public List<PermanentMerchantBean> viewVerifiedMerchant() {
		List<PermanentMerchantBean> verifiedMerchantList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from PermanentMerchantBean";
		try {

			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);

			verifiedMerchantList = query.getResultList();
			entityTransaction.commit();

		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Verified merchant list not found..");
		}
		entityManager.close();
		return verifiedMerchantList;
	}

	@Override
	public List<TemporaryMerchantBean> ViewMerchantListToVerify() {
		List<TemporaryMerchantBean> temporaryMerchantList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from TemporaryMerchantBean";
		try {

			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);

			temporaryMerchantList = query.getResultList();
			entityTransaction.commit();

		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Temporary merchant list not found..");
		}
		entityManager.close();
		return temporaryMerchantList;
	}

	@Override
	public List<TemporaryCustomerBean> ViewCustomerListToVerify() {
		List<TemporaryCustomerBean> temporaryCustomerList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from TemporaryCustomerBean";

		try {
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);

			temporaryCustomerList = query.getResultList();
			entityTransaction.commit();

		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Temporary customer list not found..");
		}
		entityManager.close();
		return temporaryCustomerList;
	}

	@Override
	public List<LoginBean> viewVerifiedCustomer() {
		List<LoginBean> verifiedCustomerList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from LoginBean where role=:role";
		try {

			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
		    query.setParameter("role", "customer");
            verifiedCustomerList = query.getResultList();
			entityTransaction.commit();

		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Verified customer list not found..");
		}
		entityManager.close();
		return verifiedCustomerList;
	}

	@Override
	public List<ProductBean> viewProduct() {
		List<ProductBean> productList = null;
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		String jpql = "from ProductBean";
		try {
			entityTransaction.begin();
			Query query = entityManager.createQuery(jpql);
			productList = query.getResultList();
			entityTransaction.commit();

		} catch (Exception e) {
			throw new CapstoreException("Something went wrong... Verified customer list not found..");

		}
		entityManager.close();
		return productList;
	}

	@Override
	public boolean merchantVerification(String email) {
		TemporaryMerchantBean temporaryMerchantBean = new TemporaryMerchantBean();
		PermanentMerchantBean permanentMerchantBean = new PermanentMerchantBean();
		LoginBean loginBean = new LoginBean();
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		
		boolean isAdded = false;
		String jpql = "from TemporaryMerchantBean where email=:email";
		try {
			Query query = entityManager.createQuery(jpql);
			query.setParameter("email", email);
			temporaryMerchantBean = (TemporaryMerchantBean) query.getSingleResult();
			permanentMerchantBean.setEmail(temporaryMerchantBean.getEmail());
			permanentMerchantBean.setName(temporaryMerchantBean.getName());
			permanentMerchantBean.setPassword(temporaryMerchantBean.getPassword());
			permanentMerchantBean.setBrandName(temporaryMerchantBean.getBrandName());
			permanentMerchantBean.setAddress(temporaryMerchantBean.getAddress());
			permanentMerchantBean.setPhoneNumber(temporaryMerchantBean.getPhoneNumber());
			permanentMerchantBean.setRole(temporaryMerchantBean.getRole());
			entityTransaction.begin();
			entityManager.persist(permanentMerchantBean);
			entityTransaction.commit();
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			loginBean.setEmail(temporaryMerchantBean.getEmail());
			loginBean.setName(temporaryMerchantBean.getName());
			loginBean.setPassword(temporaryMerchantBean.getPassword());
			loginBean.setPhoneNumber(temporaryMerchantBean.getPhoneNumber());
			loginBean.setRole(temporaryMerchantBean.getRole());
			entityTransaction.begin();
			entityManager.persist(loginBean);
			entityTransaction.commit();
			isAdded = true;
		}catch(Exception e) {
				e.printStackTrace();
			}
		
		return isAdded;
	}

	@Override
	public boolean customerVerification(String email) {
		TemporaryCustomerBean temporaryCustomerBean = new TemporaryCustomerBean();
		LoginBean loginBean = new LoginBean();
		entityManager = entityManagerFactory.createEntityManager();
		entityTransaction = entityManager.getTransaction();
		boolean isAdded = false;
		String jpql = "from TemporaryCustomerBean where email=:email";
		try {
			Query query = entityManager.createQuery(jpql);
			query.setParameter("email", email);
			temporaryCustomerBean = (TemporaryCustomerBean) query.getSingleResult();
			loginBean.setEmail(temporaryCustomerBean.getEmail());
			loginBean.setName(temporaryCustomerBean.getName());
			loginBean.setPassword(temporaryCustomerBean.getPassword());
			loginBean.setPhoneNumber(temporaryCustomerBean.getPhoneNumber());
			loginBean.setRole(temporaryCustomerBean.getRole());
			entityTransaction.begin();
			entityManager.persist(loginBean);
			entityTransaction.commit();
			isAdded = true;

		} catch (Exception e) {
			e.printStackTrace();
		}
		entityManager.close();
		return isAdded;
	}

}