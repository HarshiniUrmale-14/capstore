package com.capgemini.capstore.bdd;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinationForEmployee {
	static {
		System.setProperty("webdriver.chrome.driver", "./src/main/resources/chromedriver.exe");
	}
	WebDriver driver;

	@Given("^the  has loaded the application in the browser$")
	public void the_has_loaded_the_application_in_the_browser() throws Throwable {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("http://localhost:4200");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^click on login link$")
	public void click_on_login_link() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^the enters valid email in the emailbox$")
	public void the_enters_valid_email_in_the_emailbox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^the enters valid password in the password textbox$")
	public void the_enters_valid_password_in_the_password_textbox() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@When("^the clicks on the login button$")
	public void the_clicks_on_the_login_button() throws Throwable {
		// Write code here that turns the phrase above into concrete actions
		throw new PendingException();
	}

	@Then("^the dashboard page must be displayed$")
	public void the_dashboard_page_must_be_displayed() throws Throwable {
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@When("^click on register third party merchant  link$")
	public void click_on_register_third_party_merchant_link() throws Throwable {
		driver.findElement(By.xpath("//a[text()='THIRDPARTY REGISTER']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@When("^enter valid merchant name in textbox$")
	public void enter_valid_admin_name_in_textbox() throws Throwable {
		driver.findElement(By.name("name")).sendKeys("Mahesh Kumar");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^enter valid email id in textbox$")
	public void enter_valid_email_id_in_textbox() throws Throwable {
		driver.findElement(By.name("email")).sendKeys("abcd@gmail.com");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^enter valid mobile number in textbox$")
	public void enter_valid_mobile_number_in_textbox() throws Throwable {
		driver.findElement(By.name("phoneNumber")).sendKeys("8767567456");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^enter valid shop name or brand name in textbox$")
	public void enter_valid_shop_name_or_brand_name_in_textbox() throws Throwable {
		driver.findElement(By.name("brandName")).sendKeys("samsung");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
		

	@When("^enter valid address in textbox$")
	public void enter_valid_address_in_textbox() throws Throwable {
		driver.findElement(By.name("address")).sendKeys("karol bagh");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^enter valid password in textbox$")
	public void enter_valid_password_in_textbox() throws Throwable {
		driver.findElement(By.name("passsword")).sendKeys("Abcd123");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on register button ,third party merchant message must be displayed on the screen$")
	public void click_on_register_button_third_party_merchant_message_must_be_displayed_on_the_screen()
			throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-register-third-party-merchant/div/form/div/div[3]/button[1]")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on validate  merchant link$")
	public void click_on_validate_merchant_link() throws Throwable {
		driver.findElement(By.xpath("//a[text()='VERIFY MERCHANT']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@Then("^click on verify validate button ,the merchant is validated$")
	public void click_on_verify_validate_button_the_merchant_is_validated() throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-view-merchant-list-to-verify/div[1]/table/tbody/tr[1]/td[7]/button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on merchant list link,the merchant list is  displayed$")
	public void click_on_merchant_list_link_the_merchant_list_is_displayed() throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-view-merchant-list-to-verify/div[2]/a")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on validate the merchant link$")
	public void click_on_validate_the_merchant_link() throws Throwable {
		driver.findElement(By.xpath("//a[text()='VERIFY MERCHANT']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@Then("^click on merchant list link$")
	public void click_on_merchant_list_link() throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-view-merchant-list-to-verify/div[2]/a")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on that merchants delete button  to be deleted,the  merchant gets deleted$")
	public void click_on_that_merchants_delete_button_to_be_deleted_the_merchant_gets_deleted() throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-view-merchant-list/div/table/tbody/tr/td[7]/button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on validate  customer link$")
	public void click_on_validate_customer_link() throws Throwable {
		driver.findElement(By.xpath("//a[text()='VERIFY CUSTOMER']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@Then("^click on verify validate button ,the customer is validated$")
	public void click_on_verify_validate_button_the_customer_is_validated() throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-view-customer-list-to-verify/div[1]/table/tbody/tr[1]/td[5]/button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on customer list,the customer list is displayed$")
	public void click_on_customer_list_the_customer_list_is_displayed() throws Throwable {
		driver.findElement(By.xpath("/html/body/app-root/app-view-customer-list-to-verify/div[1]/table/tbody/tr[1]/td[5]/button")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^click on placed order  link , the order details must be displayed$")
	public void click_on_placed_order_link_the_order_details_must_be_displayed() throws Throwable {
		driver.findElement(By.xpath("//a[text()='PLACED ORDER']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@Then("^click on cancelled order link , the cancelled order details must be displayed$")
	public void click_on_cancelled_order_link_the_cancelled_order_details_must_be_displayed() throws Throwable {
		driver.findElement(By.xpath("//a[text()='CANCELLED ORDER']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

	@Then("^click on feedbacks link , the feedback must be displayed$")
	public void click_on_feedbacks_link_the_feedback_must_be_displayed() throws Throwable {
		driver.findElement(By.xpath("//a[text()='FEEDBACK']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.close();
	}

}
