package com.capgemini.correctedpdf;

public interface Readable {

	public void readBook();
	public void setBookmark();
}
