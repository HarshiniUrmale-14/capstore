package com.capgemini.correctedpdf;

public class DVD extends CD{

	int c;

	DVD(int r , int c) {
		super(r);
		this.c = c;
	}

	
}
