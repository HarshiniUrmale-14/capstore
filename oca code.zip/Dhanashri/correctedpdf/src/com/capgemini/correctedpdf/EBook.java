package com.capgemini.correctedpdf;

public class EBook  extends Book{

	public void readBook() {
		
	}
	
	public void setBookmark() {
		
	}
}
