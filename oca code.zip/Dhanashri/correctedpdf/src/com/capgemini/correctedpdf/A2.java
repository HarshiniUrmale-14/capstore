package com.capgemini.correctedpdf;
 abstract class A3{
	 private static int i;
	 public void doStuff() {}
	 public A3() {
		 
	 }
 }
 final class A1{
	 public A1() {
		 
	 }
 }
public class A2 {
private static int i;
private A2() {
	
}
}
class A4{
	protected static final int i;
	private void doStuff() {
		
	}
}
final abstract class A5{
	protected static int i;
	void doStuff();
	abstract void doIt();
}
