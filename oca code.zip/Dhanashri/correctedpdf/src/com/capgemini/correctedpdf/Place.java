package com.capgemini.correctedpdf;

abstract class Place {
 public void revolve() {
	
}
abstract void rotate();
}
class Earth extends Place{

   void revolve() {
	
}
	 protected void rotate() {
				
	}
	
}
