package com.capgemini.correctedpdf;

public class Product {

	double price;
}
