package com.capgemini.correctedpdf;

public class Machine {
void readCard( int cardNumber) throws RuntimeException{
	System.out.println("dfghjkcvbn");
}
void checkCard(int cardNumber) throws Exception{
	System.out.println("sdfghjklkjhgfd");
}
public static void main(String[] args) {
	Machine mac=new Machine();
	int card=34567;
	mac.readCard(card);
	mac.checkCard(card);
	
}
}
