package com.capgemini.correctedpdf;

public class CD {

	int r;
	CD (int r) {
		this.r = r;
	}
}
