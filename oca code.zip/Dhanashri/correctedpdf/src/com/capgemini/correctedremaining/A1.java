package com.capgemini.correctedremaining;

public class A1 {

}
