package com.capgemini.correctedremaining;

public class Caller {

	private void init() {
		System.out.println("Inintailzed");
	}
	
	private void start() {
		init();
		System.out.println("Started");
	}
}
