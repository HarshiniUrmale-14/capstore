package com.capgemini.correctedremaining;

public class C1 extends C2 implements I{

	public void displayI() {
		System.out.println("C1");
	}
}
