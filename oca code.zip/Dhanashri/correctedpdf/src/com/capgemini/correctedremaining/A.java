package com.capgemini.correctedremaining;

public class A {

	public void a() {
		
	}
	int a;
}
