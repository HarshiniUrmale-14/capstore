package com.capgemini.correctedremaining;

public class Tool implements Exportable{

	protected void export() {
		System.out.println("Tool:S");
	}
}
