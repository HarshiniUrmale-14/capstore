package com.capgemini.correctedremaining;

public interface Exportable {

	void export();
}
