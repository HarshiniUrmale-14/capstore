package com.capgemini.correctedremaining;

public interface I {

	public void displayI();
}
