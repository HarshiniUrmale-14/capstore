package com.capgemini.correctedremaining;

public class Student {

	String name;
	public Student (String name) {
		this.name = name;
	}
}
