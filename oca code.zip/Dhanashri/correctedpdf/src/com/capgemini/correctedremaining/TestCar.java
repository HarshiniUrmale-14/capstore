package com.capgemini.correctedremaining;

public class TestCar {

	public static void main(String[] args) {
		Vehicle y = new Car(20);
		System.out.println(y);
	}
}
