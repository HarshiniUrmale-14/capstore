package com.capgemini.correctedremaining;

public class MyException extends RuntimeException{

}
