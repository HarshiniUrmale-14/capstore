package com.capgemini.correctedremaining;

public class Planet {

	public String name;
	public int moon;
	
	public Planet (String name , int moon) {
		this.name = name;
		this.moon = moon;
	}
}
