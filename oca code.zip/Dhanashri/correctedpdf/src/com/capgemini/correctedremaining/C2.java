package com.capgemini.correctedremaining;

public class C2 {

	public void displayC2() {
		System.out.println("C2");
	}
}
