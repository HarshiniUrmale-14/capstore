package com.capgemini.correctedremaining;

public class Vehicle {

	int x;
	Vehicle() {
		this(10);
	}
	
	Vehicle (int x) {
		this.x = x;
	}
}


