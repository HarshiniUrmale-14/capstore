package com.capgemini.correctedremaining;

public class MyField {

	int x ;
	 int y ;
}
