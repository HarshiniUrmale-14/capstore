package com.capgemini.correctedremaining;

public class B {

	private int doStuff() {
		private int x = 100;
		return x++;
	}
}
