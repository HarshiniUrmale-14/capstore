package com.capgemini.set1andset2;

public abstract class Planet {

	protected void revolve() {
		
	}
	
	abstract void rotate();
}
