package com.capgemini.set1andset2;

import com.capgemini.package2.Acc;

public class AccTest extends Acc{

	public static void main(String[] args) {
		Acc acc = new AccTest();
		System.out.println(acc.p);
		System.out.println(acc.q);
		System.out.println(acc.r);
		System.out.println(acc.s);

	}
	
}
