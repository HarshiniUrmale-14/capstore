package com.capgemini.set1andset2;

public class Director extends Manager{

  public int stockOptions;	
}
