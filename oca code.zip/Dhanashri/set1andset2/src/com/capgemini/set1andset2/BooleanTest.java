package com.capgemini.set1andset2;

public class BooleanTest {

	public static void main(String[] args) {
		boolean a = new Boolean(Boolean.valueOf(args[0]));
		boolean b = new Boolean(args[2]);
		System.out.println(a + " " + b);
	}
}
