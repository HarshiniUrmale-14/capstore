package com.capgemini.set1andset2;

public class MyString {

	String msg;
	MyString (String msg) {
		this.msg = msg;
	}
}
