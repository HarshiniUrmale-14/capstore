package com.capgemini.set1andset2;

public class Meno {
	public static void main(String[] args) {
		boolean a=new Boolean(Boolean.valueOf(true));
		boolean b=new Boolean(null);
		System.out.println(a+""+b);
	}

}
