package com.capgemini.set1andset2;

public class XTest {

	public static void main(String[] args) throws Exception {
		X obj = new X ();
		obj.printFileContent();
	}
}
