package com.capgemini.set1andset2;

public class DerivedA extends Base{

	public void test () {
		System.out.println("DerivedA");
	}
}
