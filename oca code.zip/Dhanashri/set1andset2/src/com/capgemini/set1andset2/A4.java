package com.capgemini.set1andset2;

public class A4 {

	protected static final int i;
	private void doStuff() {
		
	}
}
