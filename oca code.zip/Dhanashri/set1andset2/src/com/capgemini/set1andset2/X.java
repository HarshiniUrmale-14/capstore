package com.capgemini.set1andset2;

import java.io.IOException;

public class X {

	public void printFileContent() throws IOException{
		
		throw new IOException();
	}
}
