package com.capgemini.set1andset2;

public class EMployee {

	public int salary;
}
