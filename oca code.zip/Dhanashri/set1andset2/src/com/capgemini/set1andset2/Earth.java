package com.capgemini.set1andset2;

public class Earth extends Planet{

	public void revolve() {
		
	}
	
	protected void rotate() {
		
	}
}
