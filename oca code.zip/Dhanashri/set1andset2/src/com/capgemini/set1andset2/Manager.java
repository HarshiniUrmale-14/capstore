package com.capgemini.set1andset2;

public class Manager extends EMployee{

	public int budget;
}
